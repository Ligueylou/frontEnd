"use client"

import { useAuth } from "../../contexts/auth-context"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Users,
  UserCheck,
  DollarSign,
  Search,
  Eye,
  CheckCircle,
  Settings,
  LogOut,
  BarChart3,
  FileText,
  CreditCard,
  Plus,
  Edit,
  Trash2,
  ArrowLeft,
  Briefcase,
  Filter,
  Ban,
  Star,
} from "lucide-react"
import Link from "next/link"
import { toast } from "sonner"

// Mock data pour les prestataires
const mockPrestataires = [
  {
    id: 1,
    nomComplet: "Amadou Diallo",
    email: "amadou.diallo@example.com",
    telephone: "77 123 45 67",
    specialite: "Plomberie",
    statut: "active",
    note: 4.8,
    services_count: 15,
    revenus: 250000,
    date_inscription: "2025-01-15",
    derniere_activite: "Il y a 2h",
  },
  {
    id: 2,
    nomComplet: "Marieme Diop",
    email: "marieme.diop@example.com",
    telephone: "76 987 65 43",
    specialite: "Ménage",
    statut: "active",
    note: 4.9,
    services_count: 28,
    revenus: 180000,
    date_inscription: "2025-01-10",
    derniere_activite: "Il y a 1h",
  },
  {
    id: 3,
    nomComplet: "Ibrahima Gueye",
    email: "ibrahima.gueye@example.com",
    telephone: "78 456 78 90",
    specialite: "Électricité",
    statut: "pending",
    note: 0,
    services_count: 0,
    revenus: 0,
    date_inscription: "2025-01-20",
    derniere_activite: "Il y a 5j",
  },
  {
    id: 4,
    nomComplet: "Fatou Sow",
    email: "fatou.sow@example.com",
    telephone: "77 234 56 78",
    specialite: "Peinture",
    statut: "active",
    note: 4.7,
    services_count: 12,
    revenus: 320000,
    date_inscription: "2025-01-05",
    derniere_activite: "Il y a 3h",
  },
  {
    id: 5,
    nomComplet: "Ousmane Ndiaye",
    email: "ousmane.ndiaye@example.com",
    telephone: "76 345 67 89",
    specialite: "Menuiserie",
    statut: "suspended",
    note: 3.2,
    services_count: 8,
    revenus: 95000,
    date_inscription: "2024-12-20",
    derniere_activite: "Il y a 1j",
  },
  {
    id: 6,
    nomComplet: "Aissatou Ba",
    email: "aissatou.ba@example.com",
    telephone: "78 567 89 01",
    specialite: "Jardinage",
    statut: "active",
    note: 4.6,
    services_count: 20,
    revenus: 150000,
    date_inscription: "2025-01-12",
    derniere_activite: "Il y a 4h",
  },
]

export default function PrestatairesPage() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatut, setFilterStatut] = useState("all")
  const [filterSpecialite, setFilterSpecialite] = useState("all")
  const [prestataires, setPrestataires] = useState(mockPrestataires)

  const handleValidatePrestataire = (prestataireId: number) => {
    setPrestataires(
      prestataires.map((p) =>
        p.id === prestataireId ? { ...p, statut: "active" } : p
      )
    )
    toast.success("Prestataire validé avec succès")
  }

  const handleSuspendPrestataire = (prestataireId: number) => {
    setPrestataires(
      prestataires.map((p) =>
        p.id === prestataireId ? { ...p, statut: p.statut === "suspended" ? "active" : "suspended" } : p
      )
    )
    toast.success("Statut du prestataire mis à jour")
  }

  const filteredPrestataires = prestataires.filter((prestataire) => {
    const matchesSearch =
      prestataire.nomComplet.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prestataire.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prestataire.specialite.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatut = filterStatut === "all" || prestataire.statut === filterStatut
    const matchesSpecialite = filterSpecialite === "all" || prestataire.specialite === filterSpecialite

    return matchesSearch && matchesStatut && matchesSpecialite
  })

  const getStatutBadge = (statut: string) => {
    switch (statut) {
      case "active":
        return <Badge className="bg-green-100 text-green-800">Actif</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">En attente</Badge>
      case "suspended":
        return <Badge className="bg-red-100 text-red-800">Suspendu</Badge>
      default:
        return <Badge variant="secondary">{statut}</Badge>
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("fr-FR", {
      style: "currency",
      currency: "XOF",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const totalPrestataires = prestataires.length
  const activePrestataires = prestataires.filter(p => p.statut === "active").length
  const pendingPrestataires = prestataires.filter(p => p.statut === "pending").length
  const totalRevenus = prestataires.reduce((acc, p) => acc + p.revenus, 0)

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-sm border-r">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">L</span>
            </div>
            <span className="font-bold text-lg">LIGUEYLU</span>
          </div>

          {/* Admin Profile */}
          <div className="flex items-center gap-3 mb-8 p-3 bg-gray-50 rounded-lg">
            <Avatar className="h-10 w-10">
              <AvatarImage src="/placeholder.svg?height=40&width=40" />
              <AvatarFallback className="bg-green-500 text-white">
                {user?.nomComplet
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">Admin</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="space-y-2">
            <Link
              href="/admin"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <BarChart3 className="h-5 w-5" />
              <span>Tableau de Bord</span>
            </Link>
            <Link
              href="/admin/users"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <Users className="h-5 w-5" />
              <span>Utilisateurs</span>
            </Link>
            <Link
              href="/admin/prestataires"
              className="flex items-center gap-3 px-3 py-2 text-green-600 bg-green-50 rounded-lg"
            >
              <UserCheck className="h-5 w-5" />
              <span className="font-medium">Prestataires</span>
            </Link>
            <Link
              href="/admin/specialites"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <Briefcase className="h-5 w-5" />
              <span>Spécialités</span>
            </Link>
            <Link
              href="/admin/services"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <CreditCard className="h-5 w-5" />
              <span>Services</span>
            </Link>
            <Link
              href="/admin/transactions"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <DollarSign className="h-5 w-5" />
              <span>Transactions</span>
            </Link>
            <Link
              href="/admin/reports"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <FileText className="h-5 w-5" />
              <span>Rapports</span>
            </Link>
          </nav>
        </div>

        {/* Bottom Actions */}
        <div className="absolute bottom-0 left-0 right-0 w-64 p-6 border-t bg-white">
          <div className="space-y-2">
            <Link
              href="/admin/profile"
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg w-full"
            >
              <Settings className="h-5 w-5" />
              <span>Profil</span>
            </Link>
            <button
              onClick={logout}
              className="flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg w-full"
            >
              <LogOut className="h-5 w-5" />
              <span>Déconnexion</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <div className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/admin">
                <Button variant="outline" size="icon">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Gestion des Prestataires</h1>
                <p className="text-gray-600">Gérez tous les prestataires de la plateforme</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Rechercher un prestataire..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nouveau Prestataire
              </Button>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Prestataires</CardTitle>
                <UserCheck className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalPrestataires}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Prestataires Actifs</CardTitle>
                <CheckCircle className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activePrestataires}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">En Attente</CardTitle>
                <Ban className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{pendingPrestataires}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Revenus Totaux</CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(totalRevenus)}</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filtres et Recherche
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <Select value={filterStatut} onValueChange={setFilterStatut}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Statut" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les statuts</SelectItem>
                    <SelectItem value="active">Actif</SelectItem>
                    <SelectItem value="pending">En attente</SelectItem>
                    <SelectItem value="suspended">Suspendu</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterSpecialite} onValueChange={setFilterSpecialite}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Spécialité" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les spécialités</SelectItem>
                    <SelectItem value="Plomberie">Plomberie</SelectItem>
                    <SelectItem value="Électricité">Électricité</SelectItem>
                    <SelectItem value="Ménage">Ménage</SelectItem>
                    <SelectItem value="Peinture">Peinture</SelectItem>
                    <SelectItem value="Menuiserie">Menuiserie</SelectItem>
                    <SelectItem value="Jardinage">Jardinage</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Prestataires Table */}
          <Card>
            <CardHeader>
              <CardTitle>Prestataires ({filteredPrestataires.length})</CardTitle>
              <CardDescription>Liste de tous les prestataires avec leurs informations</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Prestataire</TableHead>
                    <TableHead>Spécialité</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead>Note</TableHead>
                    <TableHead>Services</TableHead>
                    <TableHead>Revenus</TableHead>
                    <TableHead>Dernière activité</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPrestataires.map((prestataire) => (
                    <TableRow key={prestataire.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>
                              {prestataire.nomComplet
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{prestataire.nomComplet}</p>
                            <p className="text-sm text-gray-500">{prestataire.email}</p>
                            <p className="text-sm text-gray-500">{prestataire.telephone}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-blue-600">
                          {prestataire.specialite}
                        </Badge>
                      </TableCell>
                      <TableCell>{getStatutBadge(prestataire.statut)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="font-medium">{prestataire.note.toFixed(1)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{prestataire.services_count}</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium text-green-600">
                          {formatCurrency(prestataire.revenus)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-gray-500">{prestataire.derniere_activite}</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4 mr-1" />
                            Voir
                          </Button>
                          {prestataire.statut === "pending" && (
                            <Button
                              size="sm"
                              onClick={() => handleValidatePrestataire(prestataire.id)}
                              className="bg-green-500 hover:bg-green-600"
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Valider
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant={prestataire.statut === "suspended" ? "default" : "destructive"}
                            onClick={() => handleSuspendPrestataire(prestataire.id)}
                          >
                            {prestataire.statut === "suspended" ? (
                              <>
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Activer
                              </>
                            ) : (
                              <>
                                <Ban className="h-4 w-4 mr-1" />
                                Suspendre
                              </>
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
} 